# Scripts
Scripts for IT Professionals

This repository Contains scripts and script building notes. The Scripts contained in the repository were written for my personal use and may not all be complete.

Feel free to use, change, or share any files in this repository.

By using and/or sharing the repository contents you assume responsibility for any outcomes that may come from making use of them, for yourself and anyone whom you may share the scripts with.

By assuming responsibility you waive any and all legal actions against the creator of the repository.

I did not create every script in this repository and do not claim all scripts as my own. If you are the creator of a script and wish it to be removed let me know and I will remove the script.
