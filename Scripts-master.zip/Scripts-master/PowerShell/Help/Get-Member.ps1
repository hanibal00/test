#Get available parmaters
select-service | gm
select-service | get-member