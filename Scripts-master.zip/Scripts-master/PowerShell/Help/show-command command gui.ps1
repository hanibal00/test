#Gui tool for building command (can be useful for finding parameters)
show-command test-connection