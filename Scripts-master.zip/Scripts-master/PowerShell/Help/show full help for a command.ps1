***Show full help for a command
get-help get-service -full