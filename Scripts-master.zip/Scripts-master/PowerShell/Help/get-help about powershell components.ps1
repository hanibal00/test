***Show help with what commands or parts of powershell are for
Get-help *about*
get-help about_wmi