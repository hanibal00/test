#Prompt for input for script variables
$Computer = Read-Host "Type a Computer Name" 
