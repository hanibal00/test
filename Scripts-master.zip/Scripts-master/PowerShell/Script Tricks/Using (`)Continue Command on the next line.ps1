#Continue command on next line without it being registered as a seperate command
` backtick at the end of a command line in a script to continue the command on the next line. Commands can also be continued on the next line if the last entry was a | pipe.
