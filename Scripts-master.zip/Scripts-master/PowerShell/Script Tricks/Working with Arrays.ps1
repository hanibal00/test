#Working with arrays
$a.count get the count of items in an array
$a[0..3] 			output 4 top items in an array
$a[0]    			output top item in an array
$a[-1]   			output second to last item in an array
$a[0..9$a.count-2)] output all but last 2 items in an array
$b[0].column 		get the first item in a specific colum of an array output