#Add dates to outputed scripts for tracking
write-output get-date | outfile $outpath -append
