#Write output with variables returned
Write-output "write your message here $variable"

#Write output as a qoute no returned variable
Write-output 'write your message here $variable'

#Have comments displayed when a script is running
write-host "this is my comment" -foregroundcolor green