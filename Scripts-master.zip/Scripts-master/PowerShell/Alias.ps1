#Sets an alias
Set-Alias -Name scm -Value Show-Command

#Gets and alias
Get-Alias