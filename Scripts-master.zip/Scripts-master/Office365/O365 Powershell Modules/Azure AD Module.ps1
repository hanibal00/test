#Use "Microsoft Azure Active Directory Module for Windows PowerShell"

set-executionpolicy unrestricted
Connect-MsolService