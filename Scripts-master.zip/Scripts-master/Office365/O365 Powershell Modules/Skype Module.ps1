#Use Windows powershell (no modules)

set-executionpolicy unrestricted
New-CsOnlineSession -UserName user@domain.com