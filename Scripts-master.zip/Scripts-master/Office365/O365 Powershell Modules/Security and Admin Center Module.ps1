#Use "Microsoft Exchange Online Powershell Module"

set-executionpolicy unrestricted
Connect-IPPSSession -UserPrincipalName user@domain.com