#Use "Microsoft Exchange Online Powershell Module"

set-executionpolicy unrestricted
Connect-EXOPSSession -UserPrincipalName user@domain.com