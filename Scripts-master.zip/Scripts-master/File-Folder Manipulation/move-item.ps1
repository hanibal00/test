#move folder or items to a new location
move-item c:\test -destination c:\downloads

#show files being moved or copied
-verbose