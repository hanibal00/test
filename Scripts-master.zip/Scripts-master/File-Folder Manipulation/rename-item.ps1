#rename file or folder
rename-item c:\oldname.txt -newname c:\newname.txt

#show files being moved or copied
-verbose