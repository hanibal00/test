#list Files and folders
Get-childitem c:\folders
