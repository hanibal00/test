#Checks status of dag index state

Get-MailboxDatabaseCopyStatus 