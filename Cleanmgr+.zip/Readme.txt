	
	Links and Resources to Cleanmgr+
	===============================

	Website:  					www.imirin.com

	GitHub:					www.github.com/mirinsoft/CleanmgrPlus

	Additional Scripts:				http://www.imirin.com/downloads

	Changelog:  				http://www.imirin.com/releases

	Donate:  					http://www.imirin.com/donate


	Follow Cleanmgr+ on Twitter:
	www.twitter.com/CleanmgrPlus


	===============================
	http://www.mirinsoft.com
